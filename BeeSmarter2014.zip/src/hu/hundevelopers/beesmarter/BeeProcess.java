package hu.hundevelopers.beesmarter;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.SurfaceHolder;

public class BeeProcess extends Thread
{
	private SurfaceHolder holder;
	public boolean isRunning;
	
	public BeeProcess(SurfaceHolder holder)
	{
		this.holder = holder;
	}
	
	float y = 0.75F, my = 0F, gy = 9.81F, r = 5F;
	
	public void update()
	{
		this.y += this.my;
		this.my += this.gy/50;
		if(this.y <= this.r)
			this.my *= -0.75F;
	}
	
	public void render(Canvas canvas)
	{
		canvas.drawColor(Color.BLACK);
		Paint paint = new Paint();
		paint.setARGB(255, 255, 0, 0);
		canvas.drawCircle(canvas.getWidth()/2, canvas.getHeight()*this.y, 25, paint);
	}
	
	@Override
	public void run()
	{
		while(this.isRunning)
		{
			Canvas canvas = this.holder.lockCanvas();
			this.render(canvas);
			this.holder.unlockCanvasAndPost(canvas);
		}
	}
}
