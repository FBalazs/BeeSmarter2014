/** Automatically generated file. DO NOT MODIFY */
package hu.hundevelopers.beesmarter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}