package hu.hundevelopers.beesmarter.math;

public class Vertex
{
	public float x, y;
	
	public Vertex(float x, float y)
	{
		this.x = x;
		this.y = y;
	}
}
